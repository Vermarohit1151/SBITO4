package onetoone;
import java.sql.Date;

import javax.persistence.*;


@Entity
@Table(name="passport_2")
public class Passport {
	
	@Id
	@GeneratedValue
	@Column(name="passport_number")
	private int passportNumber;
	
	@Column(name="issued_by", length=20)
	private String issuedBy;
	
	@Column(name="passport_issued_date")
	private Date passportIssuedDate;
	
	@Column(name="passport_expiry_date")
	private Date passportExpiryDate;
	
	@OneToOne 				// Fk reference
	@JoinColumn(name="E_Number")  ///Adding a new column "E_Number" referring to @Id in Employee
	private Employee employee;
	
	public int getPassportNumber() {
		return passportNumber;
	}

	public void setPassportNumber(int passportNumber) {
		this.passportNumber = passportNumber;
	}

	public String getIssuedBy() {
		return issuedBy;
	}

	public void setIssuedBy(String issuedBy) {
		this.issuedBy = issuedBy;
	}

	public Date getPassportIssuedDate() {
		return passportIssuedDate;
	}

	public void setPassportIssuedDate(Date passportIssuedDate) {
		this.passportIssuedDate = passportIssuedDate;
	}

	public Date getPassportExpiryDate() {
		return passportExpiryDate;
	}

	public void setPassportExpiryDate(Date passportExpiryDate) {
		this.passportExpiryDate = passportExpiryDate;
	}

	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}

	@Override
	public String toString() {
		return "Passport [passportNumber=" + passportNumber + ", issuedBy=" + issuedBy + ", passportIssuedDate="
				+ passportIssuedDate + ", passportExpiryDate=" + passportExpiryDate + ", employee=" + employee + "]";
	}
	
	

}
