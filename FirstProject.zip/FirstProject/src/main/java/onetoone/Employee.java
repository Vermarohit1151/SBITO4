package onetoone;

import javax.persistence.*;

import onetomany.Department;

@Entity
@Table(name="emp1_2")
public class Employee {
	@Id
	@GeneratedValue			//Automatic increment - sequential
	@Column(name="empno")
	private int employeeNumber;
	
	@Column(name="emp_name", length=20)
	private String employeeName;
	
	@Column(name="emp_basic_sal")
	private double basicSalary;
	
	@OneToOne 	(mappedBy = "employee",cascade = CascadeType.ALL)			// Only mapped not fk
	private Passport passport;
	
	@ManyToOne
	@JoinColumn(name="dept_no")
	private Department dept;
	
	public Employee() {
		super();
	}
	public Employee( String employeeName, double basicSalary,  Department dept) {
		super();
		//this.employeeNumber = employeeNumber;
		this.employeeName = employeeName;
		this.basicSalary = basicSalary;
		//this.passport = passport;
		this.dept = dept;
	}

	public Department getDept() {
		return dept;
	}

	public void setDept(Department dept) {
		this.dept = dept;
	}

	public Passport getPassport() {
		return passport;
	}

	public void setPassport(Passport passport) {
		this.passport = passport;
	}

	public int getEmployeeNumber() {
		return employeeNumber;
	}

	public void setEmployeeNumber(int employeeNumber) {
		this.employeeNumber = employeeNumber;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public double getBasicSalary() {
		return basicSalary;
	}

	public void setBasicSalary(double basicSalary) {
		this.basicSalary = basicSalary;
	}

	
	
	
}
