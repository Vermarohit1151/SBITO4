package ManyToMany;

import java.util.Set;

import javax.persistence.*;

@Entity
@Table(name="subscription_2")
public class Subscription {
	@Id
	@Column(name="subscription_id")
	private int subId;
	
	@Column(name="subscription_name",length = 20)
	private String subscriptionName;
	
	@Column(name="subscription_duration", length = 20)
	private String duration;
	
	@ManyToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@JoinTable(
			name="customer_subscription_link",
			joinColumns = {@JoinColumn(name="sub_id")},
			inverseJoinColumns = {@JoinColumn(name="cust_id")}
	)
	private Set<Customer> customers;

	public int getSubId() {
		return subId;
	}

	public void setSubId(int subId) {
		this.subId = subId;
	}

	public String getSubscriptionName() {
		return subscriptionName;
	}

	public void setSubscriptionName(String subscriptionName) {
		this.subscriptionName = subscriptionName;
	}

	public String getDuration() {
		return duration;
	}

	public void setDuration(String string) {
		this.duration = string;
	}

	public Set<Customer> getCustomers() {
		return customers;
	}

	public void setCustomers(Set<Customer> customers) {
		this.customers = customers;
	}
	
	
}
