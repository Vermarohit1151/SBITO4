package bank;

import java.util.List;



public interface SavingsAccountDAO {
	void 			createSavingsAccount(SavingsAccount savObj);// throws AccountExistsException;
	SavingsAccount 		findSavingsAccount(int accountNumber) ;//throws AccountNOTFoundException;
	List<SavingsAccount>  findAllSavingsAccount() ;//throws EmptyTableException;
	void 			modifySavingsAccount(SavingsAccount savObj); //throws EmployeeNotFoundException;
	void 			deleteSavingsAccount(int accountNumber); //throws EmployeeNotFoundException;
}
