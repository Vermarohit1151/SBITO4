package bank;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity   //a business unit identified by its primary key
public class SavingsAccount {
	@Id
	private int accNumber;
	private double accBalance;
	private String accHolder;
	public int getAccNumber() {
		return accNumber;
	}
	public void setAccNumber(int accNumber) {
		this.accNumber = accNumber;
	}
	public double getAccBalance() {
		return accBalance;
	}
	public void setAccBalance(double accBalance) {
		this.accBalance = accBalance;
	}
	public String getAccHolder() {
		return accHolder;
	}
	public void setAccHolder(String accHolder) {
		this.accHolder = accHolder;
	}
	@Override
	public String toString() {
		return "SavingsAccount [accNumber=" + accNumber + ", accBalance=" + accBalance + ", accHolder=" + accHolder
				+ "]";
	}
	
	
}
