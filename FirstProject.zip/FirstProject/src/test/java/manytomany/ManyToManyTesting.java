package manytomany;

import java.util.Set;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import ManyToMany.Customer;
import ManyToMany.Subscription;
import base.BaseDAO;
import base.BaseDAOImpl;

public class ManyToManyTesting {

	BaseDAO base = new BaseDAOImpl();
	
	@Test
	public void addCustomersTest() {
		
		Customer cust1 = new Customer();
		cust1.setCustomerId(101);
		cust1.setCustomerName("Suresh");
		cust1.setCustomerEmail("suresh@gmail.com");
		
		Customer cust2 = new Customer();
		cust2.setCustomerId(102);
		cust2.setCustomerName("Naresh");
		cust2.setCustomerEmail("naresh@gmail.com");
		
		Customer cust3 = new Customer();
		cust3.setCustomerId(103);
		cust3.setCustomerName("Jayesh");
		cust3.setCustomerEmail("jayesh@gmail.com");
		
		base.persist(cust1);
		base.persist(cust2);
		base.persist(cust3);
	}
	
	@Test
	public void addSubscriptionsTest() {
		
		Subscription sub1 = new Subscription();
		sub1.setSubId(45);
		sub1.setSubscriptionName("Books");
		sub1.setDuration("1 month");
		
		Subscription sub2 = new Subscription();
		sub2.setSubId(55);
		sub2.setSubscriptionName("CDS");
		sub2.setDuration("3 months");

		base.persist(sub1);
		base.persist(sub2);
		
	}
	
	@Test
	public void assignExistingSubscriptionsToExistingCustomers()
	{
		Customer cust1 = base.find(Customer.class, 101);
		Subscription sub1 = base.find(Subscription.class, 45);
		Subscription sub2 = base.find(Subscription.class, 55);
		
		cust1.getSubscriptions().add(sub1);
		cust1.getSubscriptions().add(sub2);
		
		base.merge(cust1);
		
		
		
	}
	
	@Test
	public void findSubscriptionsOfACustomer() {
		Customer cust1 = base.find(Customer.class, 101);
		Assertions.assertTrue(cust1!=null);
		Set<Subscription> subSet =  cust1.getSubscriptions();
		for (Subscription subscription : subSet) {
			System.out.println("Subscription Type     : "+subscription.getSubscriptionName());
			System.out.println("Subscription Duration : "+subscription.getDuration());
		}
	}
}
