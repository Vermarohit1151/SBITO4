package onetoone;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import java.sql.Date;
import base.*;

public class OneToOneTesting {
		
	@Test
	public void addNewEmployeeWithoutPassport() {
		BaseDAO base = new BaseDAOImpl();
		Employee emp = new Employee();
		emp.setEmployeeName("Rohit Verma");
		emp.setBasicSalary(36000);
		Employee emp1 = new Employee();
		emp.setEmployeeName("Rajat Verma");
		emp.setBasicSalary(40000);
		base.persist(emp);
		base.persist(emp1);
	}


	@Test
	public void addNewPassportWithoutEmployee() {
		BaseDAO base = new BaseDAOImpl();
		Passport pass = new Passport();
		
		pass.setIssuedBy("Govt. of India");
		
		String issueddate = "2022-05-10";
		java.sql.Date issuedD = Date.valueOf(issueddate);
		pass.setPassportIssuedDate(issuedD);
		
		String expirydate = "2027-05-10";
		java.sql.Date expiryD = Date.valueOf(expirydate);
		pass.setPassportExpiryDate(expiryD);
		
		base.persist(pass);
		
		
	}
	
	@Test 
	public void addExistingPassportToExistingEmployee() {
		BaseDAO base = new BaseDAOImpl();
		Employee theEmp = base.find(Employee.class, 102);
		Passport thePass = base.find(Passport.class, 103);
		
		Assertions.assertTrue(theEmp!=null);
		Assertions.assertTrue(thePass!=null);
		
		theEmp.setPassport(thePass);
		thePass.setEmployee(theEmp);
		
		base.merge(thePass);
		base.merge(theEmp);
	}
	

	@Test
	public void  addNewEmployeeWithNewPassport() {
		BaseDAO base = new BaseDAOImpl();
		Employee theEmp = new Employee();
		Passport thePass = new Passport();
		
		theEmp.setEmployeeName("Rohit Kumar");
		theEmp.setBasicSalary(36000);
		
		thePass.setIssuedBy("GOI");
		java.sql.Date issued = Date.valueOf("2022-12-10");
		thePass.setPassportIssuedDate(issued);
		java.sql.Date expiry = Date.valueOf("2027-02-20");
		thePass.setPassportExpiryDate(expiry);
		
		thePass.setEmployee(theEmp);
		
		base.persist(theEmp);
		base.persist(thePass);
		
	}
}