package onetomany;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import base.BaseDAO;
import base.BaseDAOImpl;
import onetoone.Employee;

public class OneToManyTesting {
	BaseDAO base = new BaseDAOImpl();
	@Test
	public void addNewDepartmentWithNewEmployees() {
		
		Department dept = new Department(20,"SME Loans","GITC");
		
		Employee e1,e2,e3;
		e1 = new Employee( "Rajat", 39600, dept);
		e2 = new Employee( "Rahul", 39600, dept);
		e3 =  new Employee( "Ajay", 39600, dept);
		
		List<Employee> employees = new ArrayList<Employee>();
		employees.add(e1);
		employees.add(e2);
		employees.add(e3);
		
		dept.setEmployees(employees);
		base.merge(dept);
		
	}
	
	@Test
	public void updateEmployeeSalary() {
	
		Department dep = base.find(Department.class, 20);
		Assertions.assertTrue(dep!=null);
		
		List<Employee> empList = dep.getEmployees();
		
		for(Employee e1: empList) {
			double currentSalary = e1.getBasicSalary();
			double newSalary = currentSalary + (currentSalary*0.10);
			e1.setBasicSalary(newSalary);
			
		}
		//dep.setEmployees(empList);
		base.merge(dep);
		
	}
	
	@Test
	public void deleteEmployeeFromDepartment() {
	
		Department dep = base.find(Department.class, 20);
		Assertions.assertTrue(dep!=null);
		
		List<Employee> empList = dep.getEmployees();
		
		for(Employee e1: empList) {
			if(e1.getEmployeeNumber()==112) {
				empList.remove(e1);
				break;
			}			
		}
		//dep.setEmployees(empList);
		base.merge(dep);
		
	}
}
